Das Program kann wahlweise mit 
	java -Xmx100M -jar submission1.jar [rootFolder]
oder
	java -Xmx100M -jar submission1.jar 

Wird ein Ordner angegeben, m�ssen beide Quellordner dort vorhanden sein. Das Ergebnis wird als "result.txt" in den angegebenen Ordner geschrieben.
Wird kein Ordner angegeben, der Ordner genutzt in dem sich die JAR aktuell befindet. Die Quelldateien m�ssen in diesem Ordner vorhanden sein, die Ausgabe wird auch wieder in den aktuellen Ordner geschrieben

Zeitmessungen:
thinkpad core i5, ssd: ca. 	10min 
gruenau2:			25min